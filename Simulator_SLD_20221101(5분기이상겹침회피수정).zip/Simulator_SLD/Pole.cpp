#include "pch.h"
#include "Pole.h"


CPole::CPole()
{
}

CPole::~CPole()
{

}

