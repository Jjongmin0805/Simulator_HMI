#include "pch.h"
#include "GisObj.h"

CGisObj::CGisObj()
{
}

CGisObj::~CGisObj()
{

}

