﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// Ctrl_Object.rc에서 사용되고 있습니다.
//
#define IDD_MESSAGE_DLG                 1000
#define IDD_PROGRESS_DLG                1001
#define ID_OK                           3000
#define ID_CANCEL                       3001
#define IDC_STC_MSG                     3002
#define IDC_STC_PROG                    3003
#define CG_IDC_PROGDLG_PROGRESS         3004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1002
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         3005
#define _APS_NEXT_SYMED_VALUE           5000
#endif
#endif
