#include "pch.h"
#include "CKASIM_ND.h"

CKASIM_ND::CKASIM_ND(void)
{
	nND_ID = 0 ;
	nND_FBRID = 0;
	nND_TBRID = 0;
	nND_FCBSWID = 0;
	nND_TCBSWID = 0;
	nND_MUSW = 0;
	nND_FSVRID = 0;
	nND_TSVRID = 0;
}


CKASIM_ND::~CKASIM_ND(void)
{
}

