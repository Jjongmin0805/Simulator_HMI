﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// DND_Manager.rc에서 사용되고 있습니다.
//
#define IDD_PROGRESS_BAR_DLG            1003
#define IDC_PROGRESS1                   1004
#define IDC_STATIC_DESC2                1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1004
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
